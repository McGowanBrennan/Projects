import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class BinaryTreeTest {

	
				BinaryTreeNode node5 = new BinaryTreeNode<>(28);
				//BinaryTreeNode node7 = new BinaryTreeNode<>(123);
				//BinaryTreeNode node8 = new BinaryTreeNode<>(321);
				//BinaryTreeNode node9 = new BinaryTreeNode<>(218, node7, node8);
				//BinaryTreeNode node5 = new BinaryTreeNode<>(28, node9, null);
				BinaryTreeNode node6 = new BinaryTreeNode<>(29);
				BinaryTreeNode node3 = new BinaryTreeNode<>(28);
				BinaryTreeNode node4 = new BinaryTreeNode<>(29);
				BinaryTreeNode node2 = new BinaryTreeNode(23, node3, node4);
				BinaryTreeNode node1 = new BinaryTreeNode(23, node5, node6);
			    //BinaryTreeNode node2 = new BinaryTreeNode<>(23);
				//BinaryTreeNode node1 = new BinaryTreeNode<>(20);
				BinaryTreeNode root = new BinaryTreeNode<>(27, node1, node2);
				BinaryTreeNode root1 = new BinaryTreeNode(27, node1, node2);
				BinaryTree tree1 = new BinaryTree();
				BinaryTree tree2 = new BinaryTree();			
 
	
	@Test
	public void combineTest(){
		tree1.setRoot(node1);
		tree2.setRoot(node2);
		BinaryTreeNode testRoot = new BinaryTreeNode(21);
		tree1.combine(testRoot, tree2, true);
		//System.out.println(testRoot);
		BinaryTreeNode testThis = new BinaryTreeNode();
		testThis = tree1.getRoot();
		System.out.println(testThis == testRoot.getRight());
	}
	
	@Test
	public void combineTest2(){
		tree1.setRoot(node1);
		tree2.setRoot(node2);
		BinaryTreeNode testRoot = new BinaryTreeNode(21);
		tree1.combine(testRoot, tree2, true);
		//System.out.println(testRoot);
		BinaryTreeNode testThis = new BinaryTreeNode();
		testThis = tree1.getRoot();
		System.out.println(testThis != testRoot.getRight());
	}
				
	@Test
	public void equalsTest(){
		assertEquals(node1.equals(node2), true);
	}
	
	@Test
	public void equalsTest2(){
		assertEquals(root.equals(node1), false);
	}
	
	@Test
	public void equalsTest3(){
		assertEquals(root.equals(root1), true);
	}
	
	@Test
	public void equalsTest4(){
		tree1.setRoot(root);
		tree2.setRoot(root1);
		assertEquals(tree1.equals(tree2), true);
	}
	
	@Test
	public void equalsTest5(){
		tree2.setRoot(root1);
		assertEquals(tree1.equals(tree2), false);
	}
	
	@Test
	public void deepCopyTest2(){
		//System.out.println(root);
		root.deepCopy();
		assertEquals(root1, root);
	}
	
	@Test
	public void deepCopyTest(){
		//System.out.println(root);
		root.deepCopy();
		assertEquals(root1, root);
	}
	
	@Test
	
	public void treeInOrderTest(){
		//tree1.setRoot(root);
		//System.out.println(tree1.inOrder());
	}
	
	@Test
	public void testHeight(){
		assertEquals(root.height(), 3);
	}
	

	@Test
	public void testHeight2(){
		assertEquals(node1.height(), 2);
	}
	
	@Test
	public void fullTest(){
		assertEquals(root.full(), true);
	}
	@Test
	public void fullTest2(){
		assertEquals(node1.full(), true);
	}
	
	@Test
	public void mirrorTest(){
		node1.mirror();
		assertTrue(node1== node1);
	}
	
	@Test
	public void mirrorTest2(){
		node2.mirror();
		assertTrue(node2!= node1);
	}
}
