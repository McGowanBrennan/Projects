
public class BinaryTreeNode<T> {
	
	private BinaryTreeNode<T> left;
	private BinaryTreeNode<T> right;
	private T data;
	
	public BinaryTreeNode(){
		this(null,null,null);
	}
	
	public BinaryTreeNode(T theData){
		this(theData,null,null);
	}
	
	public BinaryTreeNode(T theData, BinaryTreeNode<T> leftChild, BinaryTreeNode<T> rightChild){
		data = theData;
		left = leftChild;
		right = rightChild;
	}
	

	
	public int size(){
		int size = 0; //the size of the tree
		
		//The size of the tree rooted at this node is one more than the
		//sum of the sizes of its children.
		if(left != null){
			size = size + left.size();
		}
		if(right != null){
			size = size + right.size();
		}
		return size + 1; //add one to account for the current node
	}

	public BinaryTreeNode<T> getLeft() {
		return left;
	}

	public void setLeft(BinaryTreeNode<T> left) {
		this.left = left;
	}
	
	public BinaryTreeNode<T> getRight() {
		return right;
	}

	public void setRight(BinaryTreeNode<T> right) {
		this.right = right;
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}
	
	
	public BinaryTreeNode<T> deepCopy(){
		BinaryTreeNode<T> copy = new BinaryTreeNode<T>();
		return deepCopyHelper(this);
	}
	
	public BinaryTreeNode<T> deepCopyHelper(BinaryTreeNode<T> current){
		BinaryTreeNode<T> copy = new BinaryTreeNode<T>(current.getData());
		if (current.left == null || current.right == null){return current;}
		copy.left =  deepCopyHelper(current.left);
		copy.right = deepCopyHelper(current.right);
		return copy;
	}
	
	@Override
	public boolean equals(Object o){
		BinaryTreeNode node = ((BinaryTreeNode<T>) o);
		 if (o == null ) return false;

		    boolean valuesEqual = this.data == node.data;
		    boolean leftEquals = this.left == null ? node.left == null : this.left.equals(node.left);
		    boolean rightEquals = this.right == null ? node.right == null : this.right.equals(node.right);

		    return valuesEqual && leftEquals && rightEquals;}
	
	public int height(){
		return heightHelper(this);
	}
		
	public int heightHelper(BinaryTreeNode<T> node){
		if(node == null) {return 0;}
		int left = heightHelper(node.left);
		int right = heightHelper(node.right);
		if(left > right){
			return 1 + left;
		}
		if(right > left){
			return 1 + right;
		}
		return 1 + left;
	}
	

	public boolean full(){
		if(fullHelper(this) == true && heightHelper(this.right) == heightHelper(this.left)){
			return true;
		}
		return false;
	}
	
	public boolean fullHelper(BinaryTreeNode<T> node){
		if (node == null){return false;}
		if (node.left == null && node.right == null){return true;}
		if (node.left != null && node.right != null){
			return fullHelper(node.right) && fullHelper(node.left);
		}
		return false;
	}
	
	public void mirror(){
		mirrorHelper(this);
	}
	
	public BinaryTreeNode<T> mirrorHelper(BinaryTreeNode<T> node){
		if (node != null){
			BinaryTreeNode<T> newNode = node.left;
			node.left = node.right;
			node.right = newNode;
			mirrorHelper(node.right);
			mirrorHelper(node.left);
		}
		return node;
	}
	
	
	
	public String inOrder(){
		return inOrderHelper(this);
	}
	
	public String inOrderHelper(BinaryTreeNode<T> node){
		if (node == null){return "";}
		inOrderHelper(node.left);
	    System.out.print("(" + node.data + ")");
	    inOrderHelper(node.right);
	    return "";
	}
	
}
