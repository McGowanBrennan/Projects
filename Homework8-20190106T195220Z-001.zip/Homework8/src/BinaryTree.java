public class BinaryTree<T> {

	private BinaryTreeNode<T> root;

	public BinaryTree() {
		this(null);
	}

	public BinaryTree(BinaryTreeNode<T> newRoot) {
		this.root = newRoot;
	}
	
	public BinaryTreeNode<T> getRoot() {
		return root;
	}

	public void setRoot(BinaryTreeNode<T> root) {
		this.root = root;
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean equals(Object o) {
		if (((BinaryTree<T>) o).getRoot() == null || this.getRoot() == null){return false;}
		return this.getRoot().equals(((BinaryTree<T>) o).getRoot());
	}

	public BinaryTree<T> deepCopy() {
		BinaryTree<T> copy = new BinaryTree<T>();
		copy.setRoot(this.getRoot().deepCopy());
		return copy;
	}

	public BinaryTree<T> combine(BinaryTreeNode<T> newRoot, BinaryTree<T> t, boolean left) {
		BinaryTree<T> thisCopy = new BinaryTree<T>();
		thisCopy = this.deepCopy();
		BinaryTree<T> inputCopy = new BinaryTree<T>();
		inputCopy = t.deepCopy();
		if (left == true){
			newRoot.setLeft(thisCopy.getRoot().deepCopy());
			newRoot.setRight(inputCopy.getRoot().deepCopy());
			BinaryTree<T> combinedTree = new BinaryTree<T>();
			combinedTree.setRoot(newRoot);
			return combinedTree;
			}
		if (left == false){
			newRoot.setLeft(inputCopy.getRoot().deepCopy());
			newRoot.setRight(thisCopy.getRoot().deepCopy());
			BinaryTree<T> combinedTree = new BinaryTree<T>();
			combinedTree.setRoot(newRoot.deepCopy());
			return combinedTree;
		}
		
		return null;
	}
	
	public BinaryTreeNode<T> combineHelper(BinaryTreeNode<T> t){
		BinaryTreeNode<T> newNode = new BinaryTreeNode<T>();
		if (t != null){
			newNode.setLeft(t.getLeft());
			newNode.setRight(t.getRight());
			combineHelper(newNode.getRight());
			combineHelper(newNode.getLeft());
		}
		return newNode;
	}
	
	public static void main(String args[]){
		//BinaryTree myTree = new BinaryTree();
		//BinaryTree yourTree = new BinaryTree();
		//BinaryTreeNode newNode5 = new BinaryTreeNode(32);
		//BinaryTreeNode newNode4 = new BinaryTreeNode(78);
		//BinaryTreeNode newNode2 = new BinaryTreeNode(34, newNode4, newNode5);
		//BinaryTreeNode newNode3 = new BinaryTreeNode();
		//BinaryTreeNode newNode1 = new BinaryTreeNode<>(23, null, newNode3);
		//BinaryTreeNode myRoot = new BinaryTreeNode();
		//myTree.setRoot(newNode2);
		//yourTree.setRoot(newNode1);
		//System.out.println(myTree.combine(myRoot, yourTree, true).toString());
		//System.out.println(myTree.inOrder());
		//System.out.println(myTree.height());
		//System.out.println(myTree.size());
		
	}
	
	
	public int size(){
		return sizeHelper(root);
	}
	
	public int sizeHelper(BinaryTreeNode<T> root){
		if (root == null){return 0;}
		else{
			
			return 1 + sizeHelper(root.getLeft()) + sizeHelper(root.getRight()); 
		}
	}
	
	public int height(){
		if (this.getRoot() == null){return 0;}
		return this.getRoot().height();
	}
	
	public int heightLeft(BinaryTreeNode<T> node){
		if (node == null){return 0;}
		return 1 + heightLeft(node.getLeft());
	}
	
	public int heightRight(BinaryTreeNode<T> node){
		if (node == null){return 0;}
		return 1 + heightRight(node.getRight());
	}
	
	public boolean full(){
		if (root == null){return false;}
		if (root.getLeft() != null && root.getRight() != null){
			return root.full();
		}
		if (root.getLeft() == null && root.getRight() == null){return true;}
		return false;
	}
	
	public void mirror(){
		this.getRoot().mirror();
	}
	
	public String inOrder(){
	if (this.getRoot() == null){return null;}
	 return this.root.inOrder();
	}
	
	public String inOrderHelper2(BinaryTreeNode<T> node){
		return node.inOrder();
	}
}
