
public class Song implements Playable, Comparable<Song>{

	private String artist;
	private String title;
	private int minutes;
	private int seconds;
	
	public void setArtist(String artist){
		this.artist = artist;
	}
	
	public String getArtist(){
		return artist;
	}
	
	public void setTitle(String title){
		this.title = title;
	}
	
	public String getTitle(){
		return title;
	}
	
	public void setMinutes(int minutes){
		this.minutes = minutes;
	}
	
	public int getMinutes(){
		return minutes;
	}
	
	public void setSeconds(int seconds){
		this.seconds = seconds;
	}
	
	public int getSeconds(){
		if (seconds > 60){
			seconds = seconds%60;
		}
		return seconds;
	}
	


	public Song(String artist, String title){
		this.artist = artist;
		this.title = title;
		this.minutes = 0;
		this.seconds = 0;
		
	}

	public Song(String artist, String title, int minutes, int seconds){
		this.artist = artist;
		this.title = title;
		this.minutes = minutes;
		this.seconds = seconds;
	}

	public Song(Song s){
		this.artist = s.getArtist();
		this.title = s.getTitle();
		this.minutes = s.getMinutes();
		this.seconds = s.getSeconds();
	}

	public boolean equals(Object o){
		if (o == null){
			return false;
		}
		if (getClass() != o.getClass()){
			return false;
		}
		Song newSong = (Song)o;
		return this.title == newSong.title && this.artist == newSong.artist && this.minutes == newSong.minutes && this.seconds == newSong.getSeconds();
	}
	
	public String toString() { // Use this code for toString EXACTLY

		   return "{Song: title = " + title + " artist = " + artist + "}";

		}
	
	public void play() { // Use this code for play EXACTLY
		   System.out.printf("Playing Song: artist = %-20s title = %s\n", artist, title);
		}
	

	@Override
	public String getName() {
		return title;
	}

	@Override
	public int compareTo(Song arg0) {
		 //Song s = (Song) arg0;
		 int result = this.getArtist().compareTo(arg0.getArtist());
		 if (result != 0) {return result;}
		 int result2 = this.getTitle().compareTo(arg0.getTitle());
		 if (result2 != 0) {return result2;}
		 return this.getTitle().compareTo(arg0.getTitle());
	}
	@Override
	public int getPlayTimeSeconds() {
		return seconds + (minutes * 60);
	}
	@Override
	public int numberOfSongs() {
		return 1;
	}
	
}
