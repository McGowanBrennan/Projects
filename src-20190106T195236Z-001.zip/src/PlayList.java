import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class PlayList implements Playable, Comparator<Playable> {

	private String name; // contains the name of the playlist
	private ArrayList<Playable> playableList; // ArrayList of Playable elements that make up the playlist
	CmpByName nameComparator = new CmpByName();
	public void setName(String name){
		this.name = name;
	}
	
	public String getName(){
		return name;
	}
	
	public void setPlayableList(ArrayList<Playable> p){
		playableList = p;
	}
	
	public ArrayList<Playable> getPlayableList(){
		return playableList;
	}
	
	public PlayList(){
		name = "Untitled";
		playableList = new ArrayList<Playable>();
	}

	public PlayList(String newName){
		name = newName;
		playableList = new ArrayList<Playable>();
	}
	
	public boolean loadSongs(String fileName){
		
		File newFile = new File(fileName);
		if (newFile.isFile()){
		int counter = 0;
		ArrayList<String> listOfTitles = new ArrayList<String>();
		ArrayList<String> listOfArtists = new ArrayList<String>();
		ArrayList<Integer> listOfMinutes = new ArrayList<Integer>();
		ArrayList<Integer> listOfSeconds = new ArrayList<Integer>();
		try {
			@SuppressWarnings("resource")
			Scanner myScanner = new Scanner(newFile);
			while (myScanner.hasNextLine()){
				//System.out.println(counter);
				if (counter == 0){
				String songTitle = myScanner.nextLine();
				songTitle = songTitle.trim();
				if (songTitle.isEmpty()) {break;}
				listOfTitles.add(songTitle);
				//counter++;
				//System.out.println(songTitle);
			//}
				//if (counter == 1){
				String songArtist = myScanner.nextLine();
				songArtist = songArtist.trim();
				listOfArtists.add(songArtist);
				//counter++;
				//System.out.println(songArtist);

			//}
				//if (counter == 2){
				String songLength = myScanner.nextLine();
				//System.out.println(songLength);
				songLength = songLength.trim();
				//System.out.println(songLength);
				int colonIndex = songLength.indexOf(':');
				//System.out.println(colonIndex);
				String songMinutes = songLength.substring(0, colonIndex);
				int songMinutesFinal = Integer.parseInt(songMinutes);
				String songSeconds = songLength.substring(colonIndex+1, songLength.length() );
				int songSecondsFinal = Integer.parseInt(songSeconds);
				if (songSecondsFinal > 60){
					int extraMinutes = songSecondsFinal/60;
					int newSeconds = songSecondsFinal % 60;
					songMinutesFinal = songMinutesFinal + extraMinutes;
					listOfMinutes.add(songMinutesFinal);
					listOfSeconds.add(newSeconds);
					//System.out.println(counter);
					counter++;
					//System.out.println(counter);
				}
				else{
					listOfMinutes.add(songMinutesFinal);
					listOfSeconds.add(songSecondsFinal);
					counter++;
				}
			//}
				if (counter == 1){
				String st = myScanner.nextLine();
				//System.out.println(st + "a");
				counter = 0;
				}
		} }
		ArrayList<Playable> songsToAdd = new ArrayList<Playable>();
		int i = 0;
		for (@SuppressWarnings("unused") String s : listOfTitles){
			songsToAdd.add(new Song(listOfArtists.get(i), listOfTitles.get(i), listOfMinutes.get(i), listOfSeconds.get(i)));
			i++;
		}
		for (Playable s : songsToAdd){
			playableList.add(s);
		}
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return true;
	}
		
		else{return false;}
	}
	
	public boolean clear(){
		for (Playable s : playableList){
			playableList.remove(s);
		}
		return true;
	}
	
	public boolean addSong(Song s){
		if (s == null){
			return false;
		}
		playableList.add(s);
		return true;
	}
	
	public Playable removePlayable(int index){
		if (playableList.contains(playableList.get(index))){
			Playable removedItem = playableList.remove(index);
			return removedItem;}
		else{return null;}
	}
	
	public Playable removePlayable(Playable p){
		for (Playable p1 : playableList){
			if (p1.equals(p)){
				playableList.remove(p);
			}
		}
		return p;
	}
	
	public Playable getPlayable(int index){
		if (index >= 0){
			return playableList.get(index);
		}
		return null;
	}

	public boolean addPlayList(PlayList pl){
		if (pl == null){
			return false;
		}
		
		for (Playable thing : playableList){
			if (thing.getName() == pl.getName()){
				return false;
		}}
			playableList.add((Playable) pl);
			return true;
	}

	@Override
	public void play() {
	}

	@Override
	public int getPlayTimeSeconds() {
		int numberOfSeconds = 0;
		for (Playable s : playableList){
			numberOfSeconds = numberOfSeconds + s.getPlayTimeSeconds();
		}
		return numberOfSeconds;
	}

	@Override
	public int numberOfSongs() {
		int numberOfSongs = 0;
		for (Playable pl : playableList){
			numberOfSongs = numberOfSongs + pl.numberOfSongs();
		}
		return numberOfSongs;
	}

	@Override
	public int compare(Playable p1, Playable p2) {
		return p1.getName().compareTo(p2.getName());
	}
	
	public void sortByName() {
		Collections.sort(playableList, nameComparator);
			
		
	}

	public void sortByTime() {
		Collections.sort(playableList, new Comparator<Playable>() {
			@Override
			public int compare(Playable p1, Playable p2) {
				return Integer.compare(p1.getPlayTimeSeconds(), p2.getPlayTimeSeconds());
			}
		});
	}
	
	
	
}
