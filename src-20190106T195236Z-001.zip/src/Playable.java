
public interface Playable {

	public void play();
	public String getName();
	public int getPlayTimeSeconds();
	public int numberOfSongs();
}
