import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class HW4Test {
	
	ArrayList<Playable> playlist = new ArrayList<Playable>();
	PlayList newPlayList = new PlayList();
	Song yesterday = new Song("The Beatles", "yesterday");
	PlayList testPlaylist = new PlayList();
	
	@Before
	public void setup(){
	ArrayList<Playable> playlist = new ArrayList<Playable>();
	Song thriller = new Song("micheal jackson", "thriller");
	Song yonk = new Song("yong gang", "yonk");
	playlist.add(thriller);
	playlist.add(yonk);
	Song yesterday = new Song("The Beatles", "yesterday");
	testPlaylist.addSong(thriller);
	
	
	
	}
	@Test
	public void testNumberOfSongs() {
		Song thriller = new Song("micheal jackson", "thriller");
		Song yonk = new Song("yong gang", "yonk");
		Assert.assertEquals(1, thriller.numberOfSongs());
	}
	
	//@Test
	/*public void testSortByNameForPLaylists(){
		ArrayList<Playable> playlist = new ArrayList<Playable>();
		Song thriller = new Song("micheal jackson", "thriller");
		Song yonk = new Song("yong gang", "yonk");
		playlist.add(thriller);
		playlist.add(yonk);
		//playLi
	}*/
	
	@Test
	public void testAddSong(){
		ArrayList<Playable> playlist = new ArrayList<Playable>();
		newPlayList.addSong(yesterday);
	}
	
	@Test
	public void testAddPLayList(){
		newPlayList.addPlayList(testPlaylist);
	}
	
	@Test
	public void testGetPlayableList(){
		newPlayList.getPlayableList();
		newPlayList.addSong(yesterday);
		System.out.println(newPlayList.getPlayableList());
	}
	
	@Test
	public void testLoadSongs(){
		System.out.println(newPlayList.loadSongs("test.txt"));
		System.out.println(newPlayList.getPlayableList());
	}

}
